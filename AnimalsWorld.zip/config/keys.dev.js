module.exports = {
    mongoURI: 'mongodb+srv://mark:VFHRvfhr007@animalworlddb.hy3rx.mongodb.net/myFirstDatabase?retryWrites=true&w=majority',
    jwt: 'dev-jwt',
    nodemailerAddress: 'example202110@gmail.com',
    nodemailerPassword: '987654321kekl'
  }