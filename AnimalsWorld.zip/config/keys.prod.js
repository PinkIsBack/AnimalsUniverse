module.exports = {
    mongoURI: process.env.mongo_URI,
    jwt: process.env.JWT,
    nodemailerAddress:process.env.nodemailerAddress ,
    nodemailerPassword: process.env.nodemailerPassword
  }